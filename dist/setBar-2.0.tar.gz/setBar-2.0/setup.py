# -*- coding: utf-8 -*-
from distutils.core import setup

setup(
	name="setBar",
	version="2.0",
	description="change status bar automaticly",
	author="Acnesu",
	author_email="mao.yuqing@foxmail.com",
	py_modules=["setBar"],
	url="http://www.acnesublog.com"
	)